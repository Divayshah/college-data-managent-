package com.example.agc_portal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
